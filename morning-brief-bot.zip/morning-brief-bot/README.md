# Morning Brief Bot

Daily 09:00 SGT Telegram briefing across Psychology, Economics, Politics, AI, Cybersecurity and Finance,
synthesized by Claude.

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # fill in the three required values
python -m src.data_fetcher  # test fetching only
python -m src.synthesizer   # test fetch + Claude (prints the brief)
python -m src.bot           # run the bot; send /briefing in Telegram
```

## Docker
```bash
docker compose up -d --build
docker compose logs -f
```
